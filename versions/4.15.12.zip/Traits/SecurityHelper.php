<?php

declare(strict_types=1);

namespace Forge\Traits;

use App\Modules\ForgeAuth\Services\UserContext;
use Forge\Core\Helpers\Redirect;
use Forge\Core\Http\Response;

trait SecurityHelper
{
    /**
     * Sanitizes input data by escaping HTML entities for security purposes.
     *
     * This method recursively processes an array of data, ensuring that all string values
     * are properly escaped using htmlspecialchars with ENT_QUOTES and UTF-8 encoding.
     * Nested arrays are processed recursively to maintain structure.
     *
     * @param array $data The input array to be sanitized
     * @return array<string, string> An array with all string values escaped and nested arrays recursively sanitized
     */
    private static function sanitize(array $data): array
    {
        $sanitized = [];
        foreach ($data as $key => $value) {
            if (is_array($value)) {
                $sanitized[$key] = self::sanitize($value);
            } else {
                $sanitized[$key] = htmlspecialchars(
                    $value,
                    ENT_QUOTES,
                    "UTF-8",
                );
            }
        }
        return $sanitized;
    }

    /**
     * Checks if the current user is logged in.
     *
     * If a user is authenticated via the UserContext, this method returns true.
     * Otherwise, it redirects the user to the root path ("/").
     *
     * @param UserContext $userContext The service instance to check user authentication
     * @return bool|Response Returns true if user is logged in, otherwise returns a Redirect response to root
     */
    public static function isLoggedIn(
        UserContext $userContext,
    ): bool|Response {
        if ($userContext->current()) {
            return true;
        } else {
            return Redirect::to("/");
        }
    }
}
