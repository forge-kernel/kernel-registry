<?php
declare(strict_types=1);

namespace Forge\Traits;
use Forge\Core\Validation\Validator;

trait ValidatorHelper
{
    /**
     * Validate data against rules
     *
     * @param array $data raw data to be validated
     * @param array $rules rules the validation should check
     * @param array $customMessages custom message to personalize validation response
     * @return void
     */
    private static function validate(array $data, array $rules, array $customMessages = []): void
    {
        $validator = new Validator($data, $rules, $customMessages);
        $validator->validate();
    }

}
