<?php

declare(strict_types=1);

namespace Forge\tests\Engine;

use App\Modules\ForgeTesting\Attributes\BeforeEach;
use App\Modules\ForgeTesting\Attributes\Group;
use App\Modules\ForgeTesting\Attributes\Test;
use App\Modules\ForgeTesting\TestCase;
use Forge\Core\DI\Container;
use Forge\Core\View\Component;
use RuntimeException;

// Dummy component for testing
#[Component(name: 'test-alert')]
class TestAlertComponent
{
    public function __construct(public array|object $props = [])
    {
    }

    public function render(): string
    {
        return '<div class="alert">' . ($this->props['message'] ?? 'default') . '</div>';
    }
}

#[Group('view')]
final class ComponentTest extends TestCase
{
    #[BeforeEach]
    public function setup(): void
    {
        // Container needed for class resolution
        Container::getInstance();

        // Register namespace alias so component loads mapping works
        class_alias('Forge\tests\Engine\TestAlertComponent', 'App\Components\TestAlert');
    }

    #[Test('Component renders by name and passes props')]
    public function render_component_by_name(): void
    {
        $html = Component::render('test-alert', ['message' => 'Warning!']);
        $this->assertEquals('<div class="alert">Warning!</div>', $html);
    }

    #[Test('Component throws RuntimeException for unknown component')]
    public function throws_for_unknown_component(): void
    {
        try {
            Component::render('missing-component');
            $this->fail('Expected RuntimeException was not thrown');
        } catch (RuntimeException $e) {
            $this->assertTrue(str_contains($e->getMessage(), 'Component class not found'));
        }
    }

    #[Test('Component caches reflection per class')]
    public function caches_reflection(): void
    {
        // First render initializes cache
        Component::render('test-alert', ['message' => '1']);

        // Second render should hit the reflection cache inside Component::$reflectionCache
        $html = Component::render('test-alert', ['message' => '2']);
        $this->assertEquals('<div class="alert">2</div>', $html);
    }
}
