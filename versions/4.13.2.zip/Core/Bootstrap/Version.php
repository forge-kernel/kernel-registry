<?php

declare(strict_types=1);

namespace Forge\Core\Bootstrap;

define("FRAMEWORK_VERSION", "4.13.2");
