<?php

declare(strict_types=1);

namespace Forge\Core\Contracts;

use Forge\Core\Http\Response;
use Forge\Core\View\ViewState;

interface ViewInterface
{
    public static function getState(): ViewState;

    public static function suppressLayout(bool $suppress = true): void;

    public static function layout(
        string $name,
        bool $loadFromModule = false,
        ?string $moduleName = null,
    ): void;

    public static function startSection(string $name): void;

    public static function endSection(): void;

    public static function section(string $name): string;

    public static function slot(
        string $name = "default",
        string $default = "",
    ): string;

    public static function component(
        string $name,
        array|object $props = [],
        bool $loadFromModule = false,
    ): string;

    public function render(string $view, array $data = []): Response;

    public static function viewComponent(
        string $path,
        array|object|null $props = [],
        ?string $module = null,
        array $slots = [],
    ): string;

    public function renderComponentView(
        string $viewSubPath,
        array|object|null $data = [],
        array $slots = [],
        ?string $module = null,
    ): string;
}
