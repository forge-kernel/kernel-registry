<?php
declare(strict_types=1);

namespace Forge\Core\View;

use Attribute;
use Forge\Core\DI\Container;
use Forge\Traits\StringHelper;
use Forge\Core\Structure\StructureResolver;
use ReflectionClass;
use ReflectionException;
use RuntimeException;

#[Attribute(Attribute::TARGET_CLASS)]
final class Component
{
    use StringHelper;

    private static array $reflectionCache = [];

    public function __construct(public string $name) {}

    /**
     * Render a component by attribute name.
     *
     * @throws ReflectionException
     */
    public static function render(
        string $name,
        array|object $props = [],
        bool $loadFromModule = false,
    ): string {
        if ($loadFromModule) {
            @trigger_error(
                "The loadFromModule parameter in Component::render() is deprecated. " .
                "Please use the ModuleName:component_name syntax instead.",
                E_USER_DEPRECATED
            );
        }

        $fqcn = self::resolveClassName($name);

        if (!class_exists($fqcn)) {
            throw new RuntimeException("Component class not found: {$fqcn}");
        }

        $cacheKey = $fqcn . "|" . $name;

        if (!isset(self::$reflectionCache[$cacheKey])) {
            $reflection = new ReflectionClass($fqcn);
            $attr = $reflection->getAttributes(self::class)[0] ?? null;
            if ($attr === null || $attr->newInstance()->name !== $name) {
                throw new RuntimeException("Attribute mismatch for {$fqcn}");
            }
            self::$reflectionCache[$cacheKey] = $reflection;
        }

        $reflection = self::$reflectionCache[$cacheKey];
        $component = $reflection->newInstance($props);
        return (string) $component->render();
    }

    private static function getStructureResolver(): ?StructureResolver
    {
        $container = Container::getInstance();
        return $container->has(StructureResolver::class)
            ? $container->get(StructureResolver::class)
            : null;
    }

    private static function resolveClassName(string $name): string
    {
        $structureResolver = self::getStructureResolver();
        $moduleName = null;
        
        if (str_contains($name, ':')) {
            [$moduleName, $name] = explode(':', $name, 2);
        }

        $parts = explode('/', $name);
        $class = self::toPascalCase(array_pop($parts));
        $subNs = array_map([self::class, "toPascalCase"], $parts);
        $subNsString = $subNs ? "\\" . implode("\\", $subNs) : "";

        if ($moduleName) {
            $baseNamespace = $structureResolver 
                ? $structureResolver->getModuleNamespace($moduleName, 'components')
                : "App\\Modules\\" . self::toPascalCase($moduleName) . "\\Resources\\Components";
                
            return $baseNamespace . $subNsString . "\\" . $class;
        }

        $baseNamespace = $structureResolver
            ? $structureResolver->getAppNamespace('components')
            : "App\\Components";

        return $baseNamespace . $subNsString . "\\" . $class;
    }
}
