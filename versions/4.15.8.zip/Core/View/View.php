<?php

declare(strict_types=1);

namespace Forge\Core\View;

use Forge\Core\DI\Container;
use Forge\Core\Helpers\ModuleHelper;
use Forge\Core\Http\Response;
use Forge\Core\View\ViewState;
use Forge\Core\View\Component;
use Forge\Core\Structure\StructureResolver;
use RuntimeException;

final class View
{
    private static ?ViewState $sharedState = null;
    public readonly ViewFinder $finder;

    public function __construct(
        private readonly Container $container,
        private ?string $viewPath = null,
        private ?string $componentPath = null,
        private readonly ?string $module = null,
    ) {
        $structureResolver = $this->container->has(StructureResolver::class)
            ? $this->container->get(StructureResolver::class)
            : null;

        if ($this->viewPath === null || $this->componentPath === null) {
            $basePath = defined("BASE_PATH") ? BASE_PATH : dirname(__DIR__, 5);

            try {
                $relViewPath = $structureResolver
                    ? $structureResolver->getAppPath("views")
                    : "app/resources/views";
                    
                $relCompPath = $structureResolver
                    ? $structureResolver->getAppPath("components")
                    : "app/resources/components";
                
                if (str_starts_with($relViewPath, 'app/') && !is_dir(BASE_PATH . "/" . $relViewPath)) {
                    $altViewPath = 'src/' . substr($relViewPath, 4);
                    if (is_dir(BASE_PATH . "/" . $altViewPath)) {
                        $relViewPath = $altViewPath;
                    }
                }
                
                if (str_starts_with($relCompPath, 'app/') && !is_dir(BASE_PATH . "/" . $relCompPath)) {
                    $altCompPath = 'src/' . substr($relCompPath, 4);
                    if (is_dir(BASE_PATH . "/" . $altCompPath)) {
                        $relCompPath = $altCompPath;
                    }
                }

                $this->viewPath ??= BASE_PATH . "/" . $relViewPath;
                $this->componentPath ??= BASE_PATH . "/" . $relCompPath;
            } catch (\InvalidArgumentException $e) {
                $this->viewPath ??= $basePath . "/app/resources/views";
                $this->componentPath ??= $basePath . "/app/resources/components";
            }
        }

        $this->finder = new ViewFinder($structureResolver, $this->viewPath, $this->componentPath);
    }

    private static function getState(): ViewState
    {
        return self::$sharedState ??= new ViewState();
    }

    public static function suppressLayout(bool $suppress = true): void
    {
        self::getState()->setShouldSuppressLayout($suppress);
    }

    /**
     * @param string $name
     * @param array $props
     * @param array $slots
     */
    public static function layout(
        string $name,
        array $props = [],
        array $slots = [],
        bool $loadFromModule = false,
        ?string $moduleName = null,
    ): void {
        if (self::getState()->shouldSuppressLayout()) {
            return;
        }
        if ($loadFromModule || $moduleName !== null) {
            @trigger_error(
                "The loadFromModule and moduleName parameters in View::layout() are deprecated. " .
                "Please use the Module:layout_name syntax instead.",
                E_USER_DEPRECATED
            );
            if ($moduleName && !str_contains($name, ':')) {
                $name = "{$moduleName}:{$name}";
            }
        }

        self::getState()->setLayout([
            "name" => $name,
            "props" => $props,
            "slots" => $slots,
        ]);
    }

    public static function startSection(string $name): void
    {
        self::getState()->startSection($name);
    }

    public static function endSection(): void
    {
        self::getState()->endSection();
    }

    public static function section(string $name): string
    {
        return self::getState()->getSection($name);
    }

    public static function slot(
        string $name = "default",
        string $default = "",
    ): string {
        return self::getState()->getSlot($name, $default);
    }

    public static function component(
        string $name,
        array|object $props = [],
        bool $loadFromModule = false,
    ): string {
        return Component::render($name, $props, $loadFromModule);
    }

    public function render(string $view, array $data = []): Response
    {
        $state = self::getState();
        try {
            $viewContent = $this->compileView($view, $data);
            $layoutInfo = $state->getLayout();

            if ($layoutInfo) {
                $layoutName = $state->getLayout()["name"];
                $layoutProps = $layoutInfo["props"] ?? [];
                $layoutSlots = $layoutInfo["slots"] ?? [];

                $processedSlots = $this->processSlots($layoutSlots);
                $state->setSlots($processedSlots);

                $layoutData = array_merge(
                    $data,
                    $layoutProps,
                    ["content" => $viewContent],
                    $state->getSections(),
                );
                $layoutFile = $this->finder->findLayout($layoutName, $this->module);
                $viewContent = $this->executeFile($layoutFile, $layoutData);
            }

            return new Response($viewContent);
        } finally {
            $state->reset();
        }
    }

    private function compileView(
        string $view,
        array $data,
    ): string {
        $viewFile = $this->finder->findView($view, $this->module);
        return $this->executeFile($viewFile, $data);
    }

    private function executeFile(string $file, array|object|null $data): string
    {
        $vars = is_object($data) ? get_object_vars($data) : $data;
        if (!empty($vars)) {
            extract($vars, EXTR_SKIP);
        }

        if (is_object($data)) {
            $props = $data;
        } else {
            $props = $data ?? [];
        }

        ob_start();
        try {
            include $file;
            return ob_get_clean();
        } catch (\Throwable $e) {
            $buffer = ob_get_clean();
            throw new RuntimeException(
                "Error rendering view [{$file}]: {$e->getMessage()}\n\nBuffer Content:\n{$buffer}",
                (int) $e->getCode(),
                $e,
            );
        }
    }

    public static function viewComponent(
        string $path,
        array|object|null $props = [],
        ?string $module = null,
        array $slots = [],
    ): string {
        $view = new self(container: Container::getInstance(), module: $module);
        $processedSlots = $view->processSlots($slots);
        return $view->renderComponentView($path, $props, $processedSlots);
    }

    private function processSlots(array $slots): array
    {
        if (empty($slots)) {
            return [];
        }

        $processed = [];

        foreach ($slots as $name => $content) {
            if (is_array($content) && isset($content["name"])) {
                $processed[$name] = function () use ($content) {
                    $componentName = $content["name"];
                    $componentProps = $content["props"] ?? [];
                    $componentSlots = $content["slots"] ?? [];

                    $componentModule = null;
                    if (str_contains($componentName, ":")) {
                        [$componentModule, $componentName] = explode(
                            ":",
                            $componentName,
                            2,
                        );
                    }

                    $nestedSlots = $this->processSlots($componentSlots);

                    return $this->renderComponentView(
                        $componentName,
                        $componentProps,
                        $nestedSlots,
                        $componentModule,
                    );
                };

                continue;
            }

            $processed[$name] = fn() => (string) $content;
        }

        return $processed;
    }

    public function renderComponentView(
        string $viewSubPath,
        array|object|null $data = [],
        array $slots = [],
        ?string $module = null,
    ): string {
        $state = self::getState();
        $previousSlots = $state->getSlots();
        $state->setSlots($slots);

        $view =
            $module !== null
            ? new self(container: $this->container, module: $module)
            : $this;

        $file = $view->finder->findComponent($viewSubPath, $view->module);
        $result = $view->executeFile($file, $data);

        $state->setSlots($previousSlots);

        return $result;
    }
}
