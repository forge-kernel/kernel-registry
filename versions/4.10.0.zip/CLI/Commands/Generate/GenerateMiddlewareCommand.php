<?php

declare(strict_types=1);

namespace Forge\CLI\Commands\Generate;

use Exception;
use Forge\CLI\Attributes\Arg;
use Forge\CLI\Attributes\Cli;
use Forge\CLI\Command;
use Forge\CLI\Traits\CliGenerator;
use Forge\Traits\StringHelper;

#[Cli(
    command: 'generate:middleware',
    description: 'Create a new middleware',
    usage: 'generate:middleware [--type=app|module] [--module=ModuleName] [--name=MiddlewareName]',
    examples: [
        'generate:middleware --type=app --name=Auth',
        'generate:middleware --type=app --name=api/Auth',
        'generate:middleware --type=module --module=Blog --name=CheckUser',
        'generate:middleware   (starts wizard)',
    ]
)]
final class GenerateMiddlewareCommand extends Command
{
    use StringHelper;
    use CliGenerator;

    #[Arg(name: 'type', description: 'app or module', validate: 'app|module')]
    private string $type;

    #[Arg(name: 'module', description: 'Module name when type=module', required: false)]
    private ?string $module = null;

    #[Arg(name: 'name', description: 'Middleware name (e.g., Auth, api/Auth, admin/CheckUser)', validate: '/^[\w\/\s-]+$/')]
    private string $name;

    /**
     * @throws Exception
     */
    public function execute(array $args): int
    {
        $this->wizard($args);

        if ($this->type === 'module' && !$this->module) {
            $this->error('--module=Name required when --type=module');
            return 1;
        }

        $middlewareFile = $this->middlewarePath();

        $parsed = $this->parseFolderFilenameForClass($this->name);
        $className = $this->toPascalCase($parsed['filename']) . 'Middleware';

        $tokens = [
            '{{ middlewareName }}'      => $className,
            '{{ middlewareNamespace }}' => $this->middlewareNamespace(),
        ];

        $this->generateFromStub('middleware', $middlewareFile, $tokens);

        $this->showPostGenerationInfo('middleware', [
            'type' => $this->type,
            'module' => $this->module,
            'name' => $this->name,
        ]);

        return 0;
    }
}
