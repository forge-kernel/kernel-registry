<?php

declare(strict_types=1);

namespace Forge\Core\Http\Middlewares;

use Forge\Core\Config\Config;
use Forge\Core\DI\Attributes\Service;
use Forge\Core\Http\Middleware;
use Forge\Core\Http\Request;
use Forge\Core\Http\Response;
use Forge\Core\Middleware\Attributes\RegisterMiddleware;
use Forge\Traits\ResponseHelper;

#[Service]
#[RegisterMiddleware(group: 'api', order: 0, allowDuplicate: true, enabled: true)]
class IpWhiteListMiddleware extends Middleware
{
    use ResponseHelper;

    public function __construct(private readonly Config $config)
    {
    }
    public function handle(Request $request, callable $next): Response
    {
        $allowedIps = $this->config->get('security.ip_whitelist');
        $clientIp = $request->getClientIp();

        if (!in_array($clientIp, $allowedIps, true)) {
            return $this->createErrorResponse($request, 'Forbidden', 403);
        }

        return $next($request);
    }
}
