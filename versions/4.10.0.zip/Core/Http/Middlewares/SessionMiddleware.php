<?php

declare(strict_types=1);

namespace Forge\Core\Http\Middlewares;

use Forge\Core\DI\Attributes\Service;
use Forge\Core\Http\Middleware;
use Forge\Core\Http\Request;
use Forge\Core\Http\Response;
use Forge\Core\Middleware\Attributes\RegisterMiddleware;
use Forge\Core\Session\SessionInterface;

#[Service]
#[RegisterMiddleware(group: 'web', order: 0, allowDuplicate: true, enabled: true)]
class SessionMiddleware extends Middleware
{
  public function __construct(
    private readonly SessionInterface $session
  ) {
  }
  public function handle(Request $request, callable $next): Response
  {
    $sessionEnabled = $_ENV['SESSION_ENABLED'] ?? true;
    if ($sessionEnabled === false || $sessionEnabled === 'false') {
      return $next($request);
    }

    $this->session->start();

    try {
      $response = $next($request);
    } finally {
      $this->session->save();
    }

    return $response;
  }
}
