<?php

declare(strict_types=1);

namespace Forge\Core\Http\Middlewares;

use Forge\Core\DI\Attributes\Service;
use Forge\Core\Http\Middleware;
use Forge\Core\Http\Request;
use Forge\Core\Http\Response;
use Forge\Core\Middleware\Attributes\RegisterMiddleware;
use Forge\Core\Security\AssetRegistry;

#[Service]
#[RegisterMiddleware(group: 'web', order: 3, allowDuplicate: true, enabled: true)]
final class RelaxSecurityHeadersMiddleware extends Middleware
{
    public function handle(Request $request, callable $next): Response
    {
        AssetRegistry::reset();

        $response = $next($request);

        $response->setHeader('X-Content-Type-Options', 'nosniff');
        $response->setHeader('X-Frame-Options', 'DENY');

        $csp = $this->buildCspHeader();

        if ($csp !== '') {
            $response->setHeader('Content-Security-Policy', $csp);
        }

        return $response;
    }

    private function buildCspHeader(): string
    {
        $config = config('security.csp');

        if (!$config || !($config['enabled'] ?? false)) {
            return '';
        }

        $directives = $config['directives'] ?? [];

        $externalSources = AssetRegistry::getCspSources();

        foreach ($externalSources as $directive => $origins) {
            if (!isset($directives[$directive])) {
                $directives[$directive] = ["'self'"];
            }

            $directives[$directive] = array_merge(
                $directives[$directive],
                $origins
            );
        }

        $parts = [];

        foreach ($directives as $directive => $values) {
            $values = array_unique($values);
            $parts[] = $directive . ' ' . implode(' ', $values);
        }

        return implode('; ', $parts);
    }
}