<?php

declare(strict_types=1);

namespace Forge\Core\Http;

use Forge\Core\Routing\Router;
use Forge\Core\Module\HookManager;
use Forge\Core\Module\LifecycleHookName;
use Throwable;

final readonly class Kernel
{
    public function __construct(private Router $router) {}

    /**
     * @throws Throwable
     */
    public function handler(Request $request): Response
    {
        HookManager::triggerHook(LifecycleHookName::BEFORE_REQUEST, $request);

        $content = $this->router->dispatch($request);

        if ($content instanceof Response) {
            HookManager::triggerHook(
                LifecycleHookName::AFTER_REQUEST,
                $request,
                $content,
            );
            return $content;
        }

        $response = new Response((string) $content);
        HookManager::triggerHook(
            LifecycleHookName::AFTER_REQUEST,
            $request,
            $response,
        );
        return $response;
    }
}
